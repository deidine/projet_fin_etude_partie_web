<footer
    style="border-top: 1px solid #333;width: 100%; position: fixed;
     bottom: 0px;text-align: center;height: 40px; line-height: 40px;background: #353a3f; ">
    Home Services &copy; <?= date("Y") ?>
</footer>
</body>

</html>