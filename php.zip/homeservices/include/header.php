<?php require_once "scripts/session.php"; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link rel="stylesheet" href="./css/bootstrap.min.css">

    <style>
        nav a.nav-link {
            color: #fff !important;
        }
    </style>

    <title>Home Services</title>
</head>

<body>
    <nav class="nav bg-dark">
        <a class="nav-link" href="about.php">About</a>
       
        <a class="nav-link" href="managehall.php">gereé les Services favoriser</a>
        <a class="nav-link" href="admin.php">gereé les admins </a>
        <a class="nav-link" href="users.php">gereé les utilisateur </a>
        <a class="nav-link" href="logout.php">Log Out</a>

    </nav>