<?php include_once "./include/header.php"; ?>

<div class="container">
    <div class="row">
        <img src="images/providers.jpeg" class="col-4 card-img-top" alt="notre Logo">

        <div class="container col-8" style="margin-top: 50px;">
            <div class="card">
                <div class="card-header text-center">
                    <strong>MIT</strong>
                </div>

                <div class="card-body">

                <h1 class="card-title">les Members du projét</h1>
                <ul>
                   <h3> <li>deidine oul cheigeur</li>
                    <li>cheikh twta</li>
                    <li>med break</li>
                    <li>ahmedou salm</li>
                </h3></ul>
            </div>

            <div class="card-footer text-center">
             <h2 style="color:yellow;">   encadrent: d. elphteh/sidi</h3>
            </div>
            </div>
        </div>
    </div>
</div>


<?php include_once "./include/footer.php"; ?>
